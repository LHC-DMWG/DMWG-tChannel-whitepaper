# This file was automatically created by FeynRules 2.3.32
# Mathematica version: 10.4.0 for Mac OS X x86 (64-bit) (February 26, 2016)
# Date: Tue 1 Oct 2019 16:32:57



from object_library import all_parameters, Parameter


from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot

# This is a default parameter object representing 0.
ZERO = Parameter(name = 'ZERO',
                 nature = 'internal',
                 type = 'real',
                 value = '0.0',
                 texname = '0')

# User-defined parameters.
lamF3d1x1 = Parameter(name = 'lamF3d1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3d1x1}',
                      lhablock = 'DMF3D',
                      lhacode = [ 1, 1 ])

lamF3d2x2 = Parameter(name = 'lamF3d2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3d2x2}',
                      lhablock = 'DMF3D',
                      lhacode = [ 2, 2 ])

lamF3d3x3 = Parameter(name = 'lamF3d3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3d3x3}',
                      lhablock = 'DMF3D',
                      lhacode = [ 3, 3 ])

lamF3Q1x1 = Parameter(name = 'lamF3Q1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3Q1x1}',
                      lhablock = 'DMF3Q',
                      lhacode = [ 1, 1 ])

lamF3Q2x2 = Parameter(name = 'lamF3Q2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3Q2x2}',
                      lhablock = 'DMF3Q',
                      lhacode = [ 2, 2 ])

lamF3Q3x3 = Parameter(name = 'lamF3Q3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3Q3x3}',
                      lhablock = 'DMF3Q',
                      lhacode = [ 3, 3 ])

lamF3u1x1 = Parameter(name = 'lamF3u1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3u1x1}',
                      lhablock = 'DMF3U',
                      lhacode = [ 1, 1 ])

lamF3u2x2 = Parameter(name = 'lamF3u2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3u2x2}',
                      lhablock = 'DMF3U',
                      lhacode = [ 2, 2 ])

lamF3u3x3 = Parameter(name = 'lamF3u3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamF3u3x3}',
                      lhablock = 'DMF3U',
                      lhacode = [ 3, 3 ])

lamS3d1x1 = Parameter(name = 'lamS3d1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamS3d1x1}',
                      lhablock = 'DMS3D',
                      lhacode = [ 1, 1 ])

lamS3d2x2 = Parameter(name = 'lamS3d2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamS3d2x2}',
                      lhablock = 'DMS3D',
                      lhacode = [ 2, 2 ])

lamS3d3x3 = Parameter(name = 'lamS3d3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamS3d3x3}',
                      lhablock = 'DMS3D',
                      lhacode = [ 3, 3 ])

lamS3Q1x1 = Parameter(name = 'lamS3Q1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamS3Q1x1}',
                      lhablock = 'DMS3Q',
                      lhacode = [ 1, 1 ])

lamS3Q2x2 = Parameter(name = 'lamS3Q2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamS3Q2x2}',
                      lhablock = 'DMS3Q',
                      lhacode = [ 2, 2 ])

lamS3Q3x3 = Parameter(name = 'lamS3Q3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamS3Q3x3}',
                      lhablock = 'DMS3Q',
                      lhacode = [ 3, 3 ])

lamS3u1x1 = Parameter(name = 'lamS3u1x1',
                      nature = 'external',
                      type = 'real',
                      value = 0.13,
                      texname = '\\text{lamS3u1x1}',
                      lhablock = 'DMS3U',
                      lhacode = [ 1, 1 ])

lamS3u2x2 = Parameter(name = 'lamS3u2x2',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamS3u2x2}',
                      lhablock = 'DMS3U',
                      lhacode = [ 2, 2 ])

lamS3u3x3 = Parameter(name = 'lamS3u3x3',
                      nature = 'external',
                      type = 'real',
                      value = 0.,
                      texname = '\\text{lamS3u3x3}',
                      lhablock = 'DMS3U',
                      lhacode = [ 3, 3 ])

aEWM1 = Parameter(name = 'aEWM1',
                  nature = 'external',
                  type = 'real',
                  value = 127.9,
                  texname = '\\text{aEWM1}',
                  lhablock = 'SMINPUTS',
                  lhacode = [ 1 ])

Gf = Parameter(name = 'Gf',
               nature = 'external',
               type = 'real',
               value = 0.0000116637,
               texname = 'G_f',
               lhablock = 'SMINPUTS',
               lhacode = [ 2 ])

aS = Parameter(name = 'aS',
               nature = 'external',
               type = 'real',
               value = 0.1184,
               texname = '\\alpha _s',
               lhablock = 'SMINPUTS',
               lhacode = [ 3 ])

ymdo = Parameter(name = 'ymdo',
                 nature = 'external',
                 type = 'real',
                 value = 0.00504,
                 texname = '\\text{ymdo}',
                 lhablock = 'YUKAWA',
                 lhacode = [ 1 ])

ymup = Parameter(name = 'ymup',
                 nature = 'external',
                 type = 'real',
                 value = 0.00255,
                 texname = '\\text{ymup}',
                 lhablock = 'YUKAWA',
                 lhacode = [ 2 ])

yms = Parameter(name = 'yms',
                nature = 'external',
                type = 'real',
                value = 0.101,
                texname = '\\text{yms}',
                lhablock = 'YUKAWA',
                lhacode = [ 3 ])

ymc = Parameter(name = 'ymc',
                nature = 'external',
                type = 'real',
                value = 1.27,
                texname = '\\text{ymc}',
                lhablock = 'YUKAWA',
                lhacode = [ 4 ])

ymb = Parameter(name = 'ymb',
                nature = 'external',
                type = 'real',
                value = 4.7,
                texname = '\\text{ymb}',
                lhablock = 'YUKAWA',
                lhacode = [ 5 ])

ymt = Parameter(name = 'ymt',
                nature = 'external',
                type = 'real',
                value = 172,
                texname = '\\text{ymt}',
                lhablock = 'YUKAWA',
                lhacode = [ 6 ])

yme = Parameter(name = 'yme',
                nature = 'external',
                type = 'real',
                value = 0.000511,
                texname = '\\text{yme}',
                lhablock = 'YUKAWA',
                lhacode = [ 11 ])

ymm = Parameter(name = 'ymm',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{ymm}',
                lhablock = 'YUKAWA',
                lhacode = [ 13 ])

ymtau = Parameter(name = 'ymtau',
                  nature = 'external',
                  type = 'real',
                  value = 1.777,
                  texname = '\\text{ymtau}',
                  lhablock = 'YUKAWA',
                  lhacode = [ 15 ])

MZ = Parameter(name = 'MZ',
               nature = 'external',
               type = 'real',
               value = 91.1876,
               texname = '\\text{MZ}',
               lhablock = 'MASS',
               lhacode = [ 23 ])

Me = Parameter(name = 'Me',
               nature = 'external',
               type = 'real',
               value = 0.000511,
               texname = '\\text{Me}',
               lhablock = 'MASS',
               lhacode = [ 11 ])

MMU = Parameter(name = 'MMU',
                nature = 'external',
                type = 'real',
                value = 0.10566,
                texname = '\\text{MMU}',
                lhablock = 'MASS',
                lhacode = [ 13 ])

MTA = Parameter(name = 'MTA',
                nature = 'external',
                type = 'real',
                value = 1.777,
                texname = '\\text{MTA}',
                lhablock = 'MASS',
                lhacode = [ 15 ])

MU = Parameter(name = 'MU',
               nature = 'external',
               type = 'real',
               value = 0.00255,
               texname = 'M',
               lhablock = 'MASS',
               lhacode = [ 2 ])

MC = Parameter(name = 'MC',
               nature = 'external',
               type = 'real',
               value = 1.27,
               texname = '\\text{MC}',
               lhablock = 'MASS',
               lhacode = [ 4 ])

MT = Parameter(name = 'MT',
               nature = 'external',
               type = 'real',
               value = 172,
               texname = '\\text{MT}',
               lhablock = 'MASS',
               lhacode = [ 6 ])

MD = Parameter(name = 'MD',
               nature = 'external',
               type = 'real',
               value = 0.00504,
               texname = '\\text{MD}',
               lhablock = 'MASS',
               lhacode = [ 1 ])

MS = Parameter(name = 'MS',
               nature = 'external',
               type = 'real',
               value = 0.101,
               texname = '\\text{MS}',
               lhablock = 'MASS',
               lhacode = [ 3 ])

MB = Parameter(name = 'MB',
               nature = 'external',
               type = 'real',
               value = 4.7,
               texname = '\\text{MB}',
               lhablock = 'MASS',
               lhacode = [ 5 ])

MH = Parameter(name = 'MH',
               nature = 'external',
               type = 'real',
               value = 125,
               texname = '\\text{MH}',
               lhablock = 'MASS',
               lhacode = [ 25 ])

MXm = Parameter(name = 'MXm',
                nature = 'external',
                type = 'real',
                value = 10.,
                texname = '\\text{MXm}',
                lhablock = 'MASS',
                lhacode = [ 52 ])

MXd = Parameter(name = 'MXd',
                nature = 'external',
                type = 'real',
                value = 13.,
                texname = '\\text{MXd}',
                lhablock = 'MASS',
                lhacode = [ 57 ])

MXs = Parameter(name = 'MXs',
                nature = 'external',
                type = 'real',
                value = 11.,
                texname = '\\text{MXs}',
                lhablock = 'MASS',
                lhacode = [ 51 ])

MXv = Parameter(name = 'MXv',
                nature = 'external',
                type = 'real',
                value = 12.,
                texname = '\\text{MXv}',
                lhablock = 'MASS',
                lhacode = [ 53 ])

MYS3Qu1 = Parameter(name = 'MYS3Qu1',
                    nature = 'external',
                    type = 'real',
                    value = 1.e8,
                    texname = '\\text{MYS3Qu1}',
                    lhablock = 'MASS',
                    lhacode = [ 1000002 ])

MYS3Qu2 = Parameter(name = 'MYS3Qu2',
                    nature = 'external',
                    type = 'real',
                    value = 1.e8,
                    texname = '\\text{MYS3Qu2}',
                    lhablock = 'MASS',
                    lhacode = [ 1000004 ])

MYS3Qu3 = Parameter(name = 'MYS3Qu3',
                    nature = 'external',
                    type = 'real',
                    value = 1.e8,
                    texname = '\\text{MYS3Qu3}',
                    lhablock = 'MASS',
                    lhacode = [ 1000006 ])

MYS3Qd1 = Parameter(name = 'MYS3Qd1',
                    nature = 'external',
                    type = 'real',
                    value = 1.e8,
                    texname = '\\text{MYS3Qd1}',
                    lhablock = 'MASS',
                    lhacode = [ 1000001 ])

MYS3Qd2 = Parameter(name = 'MYS3Qd2',
                    nature = 'external',
                    type = 'real',
                    value = 1.e8,
                    texname = '\\text{MYS3Qd2}',
                    lhablock = 'MASS',
                    lhacode = [ 1000003 ])

MYS3Qd3 = Parameter(name = 'MYS3Qd3',
                    nature = 'external',
                    type = 'real',
                    value = 1.e8,
                    texname = '\\text{MYS3Qd3}',
                    lhablock = 'MASS',
                    lhacode = [ 1000005 ])

MYS3u1 = Parameter(name = 'MYS3u1',
                   nature = 'external',
                   type = 'real',
                   value = 2000.,
                   texname = '\\text{MYS3u1}',
                   lhablock = 'MASS',
                   lhacode = [ 2000002 ])

MYS3u2 = Parameter(name = 'MYS3u2',
                   nature = 'external',
                   type = 'real',
                   value = 2.e8,
                   texname = '\\text{MYS3u2}',
                   lhablock = 'MASS',
                   lhacode = [ 2000004 ])

MYS3u3 = Parameter(name = 'MYS3u3',
                   nature = 'external',
                   type = 'real',
                   value = 2.e8,
                   texname = '\\text{MYS3u3}',
                   lhablock = 'MASS',
                   lhacode = [ 2000006 ])

MYS3d1 = Parameter(name = 'MYS3d1',
                   nature = 'external',
                   type = 'real',
                   value = 2.e8,
                   texname = '\\text{MYS3d1}',
                   lhablock = 'MASS',
                   lhacode = [ 2000001 ])

MYS3d2 = Parameter(name = 'MYS3d2',
                   nature = 'external',
                   type = 'real',
                   value = 2.e8,
                   texname = '\\text{MYS3d2}',
                   lhablock = 'MASS',
                   lhacode = [ 2000003 ])

MYS3d3 = Parameter(name = 'MYS3d3',
                   nature = 'external',
                   type = 'real',
                   value = 2.e8,
                   texname = '\\text{MYS3d3}',
                   lhablock = 'MASS',
                   lhacode = [ 2000005 ])

MYF3Qu1 = Parameter(name = 'MYF3Qu1',
                    nature = 'external',
                    type = 'real',
                    value = 3.e8,
                    texname = '\\text{MYF3Qu1}',
                    lhablock = 'MASS',
                    lhacode = [ 5910002 ])

MYF3Qu2 = Parameter(name = 'MYF3Qu2',
                    nature = 'external',
                    type = 'real',
                    value = 3.e8,
                    texname = '\\text{MYF3Qu2}',
                    lhablock = 'MASS',
                    lhacode = [ 5910004 ])

MYF3Qu3 = Parameter(name = 'MYF3Qu3',
                    nature = 'external',
                    type = 'real',
                    value = 3.e8,
                    texname = '\\text{MYF3Qu3}',
                    lhablock = 'MASS',
                    lhacode = [ 5910006 ])

MYF3Qd1 = Parameter(name = 'MYF3Qd1',
                    nature = 'external',
                    type = 'real',
                    value = 3.e8,
                    texname = '\\text{MYF3Qd1}',
                    lhablock = 'MASS',
                    lhacode = [ 5910001 ])

MYF3Qd2 = Parameter(name = 'MYF3Qd2',
                    nature = 'external',
                    type = 'real',
                    value = 3.e8,
                    texname = '\\text{MYF3Qd2}',
                    lhablock = 'MASS',
                    lhacode = [ 5910003 ])

MYF3Qd3 = Parameter(name = 'MYF3Qd3',
                    nature = 'external',
                    type = 'real',
                    value = 3.e8,
                    texname = '\\text{MYF3Qd3}',
                    lhablock = 'MASS',
                    lhacode = [ 5910005 ])

MYF3u1 = Parameter(name = 'MYF3u1',
                   nature = 'external',
                   type = 'real',
                   value = 4.e8,
                   texname = '\\text{MYF3u1}',
                   lhablock = 'MASS',
                   lhacode = [ 5920002 ])

MYF3u2 = Parameter(name = 'MYF3u2',
                   nature = 'external',
                   type = 'real',
                   value = 4.e8,
                   texname = '\\text{MYF3u2}',
                   lhablock = 'MASS',
                   lhacode = [ 5920004 ])

MYF3u3 = Parameter(name = 'MYF3u3',
                   nature = 'external',
                   type = 'real',
                   value = 4.e8,
                   texname = '\\text{MYF3u3}',
                   lhablock = 'MASS',
                   lhacode = [ 5920006 ])

MYF3d1 = Parameter(name = 'MYF3d1',
                   nature = 'external',
                   type = 'real',
                   value = 4.e8,
                   texname = '\\text{MYF3d1}',
                   lhablock = 'MASS',
                   lhacode = [ 5920001 ])

MYF3d2 = Parameter(name = 'MYF3d2',
                   nature = 'external',
                   type = 'real',
                   value = 4.e8,
                   texname = '\\text{MYF3d2}',
                   lhablock = 'MASS',
                   lhacode = [ 5920003 ])

MYF3d3 = Parameter(name = 'MYF3d3',
                   nature = 'external',
                   type = 'real',
                   value = 4.e8,
                   texname = '\\text{MYF3d3}',
                   lhablock = 'MASS',
                   lhacode = [ 5920005 ])

WZ = Parameter(name = 'WZ',
               nature = 'external',
               type = 'real',
               value = 2.4952,
               texname = '\\text{WZ}',
               lhablock = 'DECAY',
               lhacode = [ 23 ])

WW = Parameter(name = 'WW',
               nature = 'external',
               type = 'real',
               value = 2.085,
               texname = '\\text{WW}',
               lhablock = 'DECAY',
               lhacode = [ 24 ])

WT = Parameter(name = 'WT',
               nature = 'external',
               type = 'real',
               value = 1.50833649,
               texname = '\\text{WT}',
               lhablock = 'DECAY',
               lhacode = [ 6 ])

WH = Parameter(name = 'WH',
               nature = 'external',
               type = 'real',
               value = 0.00407,
               texname = '\\text{WH}',
               lhablock = 'DECAY',
               lhacode = [ 25 ])

WYS3Qu1 = Parameter(name = 'WYS3Qu1',
                    nature = 'external',
                    type = 'real',
                    value = 10.,
                    texname = '\\text{WYS3Qu1}',
                    lhablock = 'DECAY',
                    lhacode = [ 1000002 ])

WYS3Qu2 = Parameter(name = 'WYS3Qu2',
                    nature = 'external',
                    type = 'real',
                    value = 11.,
                    texname = '\\text{WYS3Qu2}',
                    lhablock = 'DECAY',
                    lhacode = [ 1000004 ])

WYS3Qu3 = Parameter(name = 'WYS3Qu3',
                    nature = 'external',
                    type = 'real',
                    value = 12.,
                    texname = '\\text{WYS3Qu3}',
                    lhablock = 'DECAY',
                    lhacode = [ 1000006 ])

WYS3Qd1 = Parameter(name = 'WYS3Qd1',
                    nature = 'external',
                    type = 'real',
                    value = 13.,
                    texname = '\\text{WYS3Qd1}',
                    lhablock = 'DECAY',
                    lhacode = [ 1000001 ])

WYS3Qd2 = Parameter(name = 'WYS3Qd2',
                    nature = 'external',
                    type = 'real',
                    value = 14.,
                    texname = '\\text{WYS3Qd2}',
                    lhablock = 'DECAY',
                    lhacode = [ 1000003 ])

WYS3Qd3 = Parameter(name = 'WYS3Qd3',
                    nature = 'external',
                    type = 'real',
                    value = 15.,
                    texname = '\\text{WYS3Qd3}',
                    lhablock = 'DECAY',
                    lhacode = [ 1000005 ])

WYS3u1 = Parameter(name = 'WYS3u1',
                   nature = 'external',
                   type = 'real',
                   value = 20.,
                   texname = '\\text{WYS3u1}',
                   lhablock = 'DECAY',
                   lhacode = [ 2000002 ])

WYS3u2 = Parameter(name = 'WYS3u2',
                   nature = 'external',
                   type = 'real',
                   value = 21.,
                   texname = '\\text{WYS3u2}',
                   lhablock = 'DECAY',
                   lhacode = [ 2000004 ])

WYS3u3 = Parameter(name = 'WYS3u3',
                   nature = 'external',
                   type = 'real',
                   value = 22.,
                   texname = '\\text{WYS3u3}',
                   lhablock = 'DECAY',
                   lhacode = [ 2000006 ])

WYS3d1 = Parameter(name = 'WYS3d1',
                   nature = 'external',
                   type = 'real',
                   value = 23.,
                   texname = '\\text{WYS3d1}',
                   lhablock = 'DECAY',
                   lhacode = [ 2000001 ])

WYS3d2 = Parameter(name = 'WYS3d2',
                   nature = 'external',
                   type = 'real',
                   value = 24.,
                   texname = '\\text{WYS3d2}',
                   lhablock = 'DECAY',
                   lhacode = [ 2000003 ])

WYS3d3 = Parameter(name = 'WYS3d3',
                   nature = 'external',
                   type = 'real',
                   value = 25.,
                   texname = '\\text{WYS3d3}',
                   lhablock = 'DECAY',
                   lhacode = [ 2000005 ])

WYF3Qu1 = Parameter(name = 'WYF3Qu1',
                    nature = 'external',
                    type = 'real',
                    value = 30.,
                    texname = '\\text{WYF3Qu1}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910002 ])

WYF3Qu2 = Parameter(name = 'WYF3Qu2',
                    nature = 'external',
                    type = 'real',
                    value = 31.,
                    texname = '\\text{WYF3Qu2}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910004 ])

WYF3Qu3 = Parameter(name = 'WYF3Qu3',
                    nature = 'external',
                    type = 'real',
                    value = 32.,
                    texname = '\\text{WYF3Qu3}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910006 ])

WYF3Qd1 = Parameter(name = 'WYF3Qd1',
                    nature = 'external',
                    type = 'real',
                    value = 33.,
                    texname = '\\text{WYF3Qd1}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910001 ])

WYF3Qd2 = Parameter(name = 'WYF3Qd2',
                    nature = 'external',
                    type = 'real',
                    value = 34.,
                    texname = '\\text{WYF3Qd2}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910003 ])

WYF3Qd3 = Parameter(name = 'WYF3Qd3',
                    nature = 'external',
                    type = 'real',
                    value = 35.,
                    texname = '\\text{WYF3Qd3}',
                    lhablock = 'DECAY',
                    lhacode = [ 5910005 ])

WYF3u1 = Parameter(name = 'WYF3u1',
                   nature = 'external',
                   type = 'real',
                   value = 40.,
                   texname = '\\text{WYF3u1}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920002 ])

WYF3u2 = Parameter(name = 'WYF3u2',
                   nature = 'external',
                   type = 'real',
                   value = 41.,
                   texname = '\\text{WYF3u2}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920004 ])

WYF3u3 = Parameter(name = 'WYF3u3',
                   nature = 'external',
                   type = 'real',
                   value = 42.,
                   texname = '\\text{WYF3u3}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920006 ])

WYF3d1 = Parameter(name = 'WYF3d1',
                   nature = 'external',
                   type = 'real',
                   value = 43.,
                   texname = '\\text{WYF3d1}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920001 ])

WYF3d2 = Parameter(name = 'WYF3d2',
                   nature = 'external',
                   type = 'real',
                   value = 44.,
                   texname = '\\text{WYF3d2}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920003 ])

WYF3d3 = Parameter(name = 'WYF3d3',
                   nature = 'external',
                   type = 'real',
                   value = 45.,
                   texname = '\\text{WYF3d3}',
                   lhablock = 'DECAY',
                   lhacode = [ 5920005 ])

aEW = Parameter(name = 'aEW',
                nature = 'internal',
                type = 'real',
                value = '1/aEWM1',
                texname = '\\alpha _{\\text{EW}}')

G = Parameter(name = 'G',
              nature = 'internal',
              type = 'real',
              value = '2*cmath.sqrt(aS)*cmath.sqrt(cmath.pi)',
              texname = 'G')

MW = Parameter(name = 'MW',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(MZ**2/2. + cmath.sqrt(MZ**4/4. - (aEW*cmath.pi*MZ**2)/(Gf*cmath.sqrt(2))))',
               texname = 'M_W')

ee = Parameter(name = 'ee',
               nature = 'internal',
               type = 'real',
               value = '2*cmath.sqrt(aEW)*cmath.sqrt(cmath.pi)',
               texname = 'e')

sw2 = Parameter(name = 'sw2',
                nature = 'internal',
                type = 'real',
                value = '1 - MW**2/MZ**2',
                texname = '\\text{sw2}')

cw = Parameter(name = 'cw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(1 - sw2)',
               texname = 'c_w')

sw = Parameter(name = 'sw',
               nature = 'internal',
               type = 'real',
               value = 'cmath.sqrt(sw2)',
               texname = 's_w')

g1 = Parameter(name = 'g1',
               nature = 'internal',
               type = 'real',
               value = 'ee/cw',
               texname = 'g_1')

gw = Parameter(name = 'gw',
               nature = 'internal',
               type = 'real',
               value = 'ee/sw',
               texname = 'g_w')

vev = Parameter(name = 'vev',
                nature = 'internal',
                type = 'real',
                value = '(2*MW*sw)/ee',
                texname = '\\text{vev}')

lam = Parameter(name = 'lam',
                nature = 'internal',
                type = 'real',
                value = 'MH**2/(2.*vev**2)',
                texname = '\\text{lam}')

yb = Parameter(name = 'yb',
               nature = 'internal',
               type = 'real',
               value = '(ymb*cmath.sqrt(2))/vev',
               texname = '\\text{yb}')

yc = Parameter(name = 'yc',
               nature = 'internal',
               type = 'real',
               value = '(ymc*cmath.sqrt(2))/vev',
               texname = '\\text{yc}')

ydo = Parameter(name = 'ydo',
                nature = 'internal',
                type = 'real',
                value = '(ymdo*cmath.sqrt(2))/vev',
                texname = '\\text{ydo}')

ye = Parameter(name = 'ye',
               nature = 'internal',
               type = 'real',
               value = '(yme*cmath.sqrt(2))/vev',
               texname = '\\text{ye}')

ym = Parameter(name = 'ym',
               nature = 'internal',
               type = 'real',
               value = '(ymm*cmath.sqrt(2))/vev',
               texname = '\\text{ym}')

ys = Parameter(name = 'ys',
               nature = 'internal',
               type = 'real',
               value = '(yms*cmath.sqrt(2))/vev',
               texname = '\\text{ys}')

yt = Parameter(name = 'yt',
               nature = 'internal',
               type = 'real',
               value = '(ymt*cmath.sqrt(2))/vev',
               texname = '\\text{yt}')

ytau = Parameter(name = 'ytau',
                 nature = 'internal',
                 type = 'real',
                 value = '(ymtau*cmath.sqrt(2))/vev',
                 texname = '\\text{ytau}')

yup = Parameter(name = 'yup',
                nature = 'internal',
                type = 'real',
                value = '(ymup*cmath.sqrt(2))/vev',
                texname = '\\text{yup}')

muH = Parameter(name = 'muH',
                nature = 'internal',
                type = 'real',
                value = 'cmath.sqrt(lam*vev**2)',
                texname = '\\mu')

I1a11 = Parameter(name = 'I1a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'ydo',
                  texname = '\\text{I1a11}')

I1a22 = Parameter(name = 'I1a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'ys',
                  texname = '\\text{I1a22}')

I1a33 = Parameter(name = 'I1a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yb',
                  texname = '\\text{I1a33}')

I2a11 = Parameter(name = 'I2a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yup',
                  texname = '\\text{I2a11}')

I2a22 = Parameter(name = 'I2a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yc',
                  texname = '\\text{I2a22}')

I2a33 = Parameter(name = 'I2a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yt',
                  texname = '\\text{I2a33}')

I3a11 = Parameter(name = 'I3a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yup',
                  texname = '\\text{I3a11}')

I3a22 = Parameter(name = 'I3a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yc',
                  texname = '\\text{I3a22}')

I3a33 = Parameter(name = 'I3a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yt',
                  texname = '\\text{I3a33}')

I4a11 = Parameter(name = 'I4a11',
                  nature = 'internal',
                  type = 'complex',
                  value = 'ydo',
                  texname = '\\text{I4a11}')

I4a22 = Parameter(name = 'I4a22',
                  nature = 'internal',
                  type = 'complex',
                  value = 'ys',
                  texname = '\\text{I4a22}')

I4a33 = Parameter(name = 'I4a33',
                  nature = 'internal',
                  type = 'complex',
                  value = 'yb',
                  texname = '\\text{I4a33}')

