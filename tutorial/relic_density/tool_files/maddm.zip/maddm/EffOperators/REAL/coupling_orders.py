# This file was automatically created by FeynRules 2.0.20
# Mathematica version: 9.0 for Linux x86 (64-bit) (November 20, 2012)
# Date: Tue 20 Jan 2015 14:25:58


from object_library import all_orders, CouplingOrder


#QCD = CouplingOrder(name = 'QCD',
#                    expansion_order = 99,
#                    hierarchy = 1)

#QED = CouplingOrder(name = 'QED',
#                    expansion_order = 99,
#                    hierarchy = 2)

SDEFFF = CouplingOrder(name = 'SDEFFF',
                       expansion_order = 99,
                       hierarchy = 1)

SDEFFV = CouplingOrder(name = 'SDEFFV',
                       expansion_order = 99,
                       hierarchy = 1)

SIEFFF = CouplingOrder(name = 'SIEFFF',
                       expansion_order = 99,
                       hierarchy = 1)

SIEFFS = CouplingOrder(name = 'SIEFFS',
                       expansion_order = 99,
                       hierarchy = 1)

SIEFFV = CouplingOrder(name = 'SIEFFV',
                       expansion_order = 99,
                       hierarchy = 1)

